import dateutil as dt
import pandas as pd
import read

def times():
    df = read.load_data()
    timestamps = df["submission_time"].dropna()
    timestamps_parsed = timestamps.apply(dt.parser.parse)
    
    times_hours = []
    for t in timestamps_parsed:
        times_hours.append(t.hour)
    times_hours_count = pd.value_counts(times_hours)
    print(times_hours_count)


if __name__ == "__main__":
   # This will call load_data if you run the script from the command line.
   times()