def no_subdomain(url):
    import pandas as pd
    
    if pd.isnull(url):
        return url 
    url = str(url)
    url = url.replace("co.uk","co-uk")
    url = url.replace("co.au","co-au")
    # If . character appears more than once, there is a subdomain, so remove everything before the first  . character
    while url.count('.') > 1:
        index = url.find('.')
        url = url[index+1:]
    url = url.replace("co-uk","co.uk")
    url = url.replace("co-au","co.au")
    return url

def domains():
    import read
    import pandas as pd
    import re
    
    df = read.load_data()
    domains = df["url"].dropna()
    domains2 = domains.apply(no_subdomain)
    
    count_domain = pd.value_counts(domains2)
    count_domain = count_domain[:100]
    for name, row in count_domain.items():
        print("{0}: {1}".format(name, row))
    

if __name__ == "__main__":
   # This will call load_data if you run the script from the command line.
   domains()