def removekey(d, lista):
    r = dict(d)
    for key in lista:
        del r[key]
    return r

def count():
    import read
    import re
    import collections as cl
    
    df = read.load_data()
    df["headline"] = df["headline"].str.lower()
    s = df["headline"].str.cat(sep=" ")
    #s = s.translate("?()[]")
    s = re.sub('[^A-Za-z0-9 ]+', '', s)
    spl = s.split(" ")
    
    dict_word = {}
    for word in spl:
        if word not in dict_word:
            dict_word[word] = 1
        else:
            dict_word[word] += 1
    
    #Inserting a dictionary of non-words
    not_words = ['the','','to','a','of','for','in','and','is', 'on','hn','with','how','your','you', 'from','new','why','what','an','are','by','at', 'it','show','do','i','not','that','as','be','1', 'its','my','us','get','them','can','this','out', 'our','we','or','5','8','have','more','make','vs', 'then','no','10','dont','has','if','3','their']
    new_dict_word = removekey(dict_word,not_words)
            
    c = cl.Counter(new_dict_word).most_common(100)
    print(c)

if __name__ == "__main__":
   # This will call load_data if you run the script from the command line.
   count()